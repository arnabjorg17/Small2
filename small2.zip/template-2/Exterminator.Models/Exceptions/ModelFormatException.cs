using System;

namespace Exterminator.Models.Exceptions
{
  public class ModelFormatExceptions : Exception
  {
    public ModelFormatExceptions() : base("Model is not properly formatted.") {}

    public ModelFormatExceptions(string message) : base(message) {}

    public ModelFormatExceptions(string message, Exception inner) : base(message, inner) {}


  }
}